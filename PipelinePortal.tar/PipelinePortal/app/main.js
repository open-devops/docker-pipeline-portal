"use strict";
var platform_browser_dynamic_1 = require('@angular/platform-browser-dynamic');
var site_component_1 = require('./site/site.component');
var app_routes_1 = require('./app.routes');
platform_browser_dynamic_1.bootstrap(site_component_1.SiteComponent, [
    app_routes_1.appRouterProviders
])
    .catch(function (err) { return console.error(err); });
//# sourceMappingURL=main.js.map