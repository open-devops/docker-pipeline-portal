import { RouterConfig } from '@angular/router';

import { DashboardComponent } from './component/dashboard.component';

export const dashbaordRoutes: RouterConfig = [
    {
        path: '',
        redirectTo: '/dashboard',
        pathMatch: 'full'
    },
    {
        path: 'dashboard',
        component: DashboardComponent
    }
]; 