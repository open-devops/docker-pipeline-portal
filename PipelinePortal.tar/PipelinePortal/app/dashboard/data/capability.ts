export class Capability {
    id: string;
    role: string;
    name: string;
    decription: string;
    img: string;
    url: string;
    dispGroup: number;
    dispIndex: number;
}