"use strict";
var Capability = (function () {
    function Capability() {
    }
    return Capability;
}());
exports.Capability = Capability;
//# sourceMappingURL=capability.js.map