import { Component, OnInit } from '@angular/core';
import { ROUTER_DIRECTIVES } from '@angular/router';
import { Capability } from '../data/capability';
import { CapabilityService } from '../service/dashboard.service';
import { HTTP_PROVIDERS } from '@angular/http';

@Component({
    moduleId: module.id,
    selector: 'devops-pipline-portal',
    templateUrl: '../template/dashboard.component.html',
    styleUrls: ['../style/dashboard.component.css'],
    directives: [ROUTER_DIRECTIVES],
    providers: [
        CapabilityService,
        HTTP_PROVIDERS
    ]
})

export class DashboardComponent implements OnInit{
    capabilities: Capability[];
    error: any;

    constructor(
        private capabilityService: CapabilityService
    ) { }

    getCapabilities() {
        this.capabilityService
            .getCapabilities()
            .then(capabilities => this.capabilities = capabilities)
            .catch(error => this.error = error);
    }

    ngOnInit() {
        this.getCapabilities();
    }
}