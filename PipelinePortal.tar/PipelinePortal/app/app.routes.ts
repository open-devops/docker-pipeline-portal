import { provideRouter, RouterConfig } from '@angular/router';

import { dashbaordRoutes } from './dashboard/dashboard.routes';

export const routes: RouterConfig = [
    ...dashbaordRoutes
];

export const appRouterProviders = [
    provideRouter(routes)
];