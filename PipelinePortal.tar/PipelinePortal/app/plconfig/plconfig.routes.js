"use strict";
var plconfig_component_1 = require('./component/plconfig.component');
exports.plconfigRoutes = [
    {
        path: '',
        redirectTo: '/plconfig',
        pathMatch: 'full'
    },
    {
        path: 'plconfig',
        component: plconfig_component_1.PLConfigComponent
    }
];
//# sourceMappingURL=plconfig.routes.js.map