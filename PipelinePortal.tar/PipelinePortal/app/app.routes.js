"use strict";
var router_1 = require('@angular/router');
var plconfig_routes_1 = require('./plconfig/plconfig.routes');
exports.routes = plconfig_routes_1.plconfigRoutes.slice();
exports.appRouterProviders = [
    router_1.provideRouter(exports.routes)
];
//# sourceMappingURL=app.routes.js.map