"use strict";
var router_1 = require('@angular/router');
var dashboard_routes_1 = require('./dashboard/dashboard.routes');
exports.routes = dashboard_routes_1.dashbaordRoutes.slice();
exports.appRouterProviders = [
    router_1.provideRouter(exports.routes)
];
//# sourceMappingURL=app.routes.js.map